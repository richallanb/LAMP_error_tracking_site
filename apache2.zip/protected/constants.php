<?php
  define ("ADMIN", 3);
  define ("DEV", 2);
  define ("DEVDEV", 1);
  define ("USER", 0);
  define ("ANON", -1);
?>