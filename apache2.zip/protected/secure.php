<?php
// This file MUST stay outside of document root.
// If it is ever found in document root I will smack you.
define ('mysqli_host', '104.131.195.24');
define ('mysqli_user',  'niner');
define ('mysqli_pw', 'MongooseHippopotomoose');
define ('mysqli_port', '3306');
define ('mysqli_db', 'teamNine');
?>
